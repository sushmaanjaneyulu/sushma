package com.example.welcome.cakebakingapp;

import com.google.gson.annotations.Expose;

import org.parceler.Parcel;

/**
 * Created by welcome on 6/12/2018.
 */
@Parcel
public class BakingIngredients {

    @Expose
    public String ingredient;
    @Expose
    public String measure;
    @Expose
    public String quantity;
}
