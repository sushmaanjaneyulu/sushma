package com.example.welcome.cakebakingapp;

import android.content.ComponentName;
import android.content.SharedPreferences;
import android.content.Intent;
import org.parceler.Parcels;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindBool;
import butterknife.BindView;
import android.appwidget.AppWidgetManager;

import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.welcome.cakebakingapp.Bakingapi.retrofit;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.recipes)RecyclerView recyclerView;
    @BindBool(R.bool.isTablet)boolean isTablet;
    private RecipecakeAdapter rAdapter;
    private StaggeredGridLayoutManager staggeredGridLayoutManager;
    private int cardsInRow;
    private ArrayList<RecipeCake> list;
    RecipecakeAdapter.OnItemClickListener onItemClickListener=new RecipecakeAdapter.OnItemClickListener() {
        @Override
        public void onItemClick(View view, int position) {
            List<BakingIngredients> ingredientWidget=list.get(position).ingredients;
            StringBuilder stringBuilder=new StringBuilder();
            for (int i=0;i<ingredientWidget.size();i++){
                int serial=i+1;
                stringBuilder.append(serial + "- " + ingredientWidget.get(i).quantity +" "+ingredientWidget.get(i).measure +" "+ingredientWidget.get(i).ingredient);
            }
            SharedPreferences sharedPreferences=getSharedPreferences("Recipe",0);
            SharedPreferences.Editor editor=sharedPreferences.edit();
            editor.putString("ingredientsWidget",stringBuilder.toString());
            editor.putString("title",list.get(position).name);
            editor.apply();

            int[] ids=AppWidgetManager.getInstance(getApplicationContext()).getAppWidgetIds(new ComponentName(getApplication(),CakeBakingAppWidget.class));
            CakeBakingAppWidget cakeBakingAppWidget=new CakeBakingAppWidget();
            Intent intent=new Intent(getBaseContext(),ItemListActivity.class);
            intent.putExtra("title",list.get(position).name);
            intent.putExtra("ingredients",Parcels.wrap(list.get(position).ingredients));
            intent.putExtra("steps",Parcels.wrap(list.get(position).steps));
            startActivity(intent);
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);

        cardsInRow=(isTablet)? 2: 1;
        staggeredGridLayoutManager=new StaggeredGridLayoutManager(cardsInRow,StaggeredGridLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(staggeredGridLayoutManager);
        recyclerView.setHasFixedSize(true);
        final Bakingapi api=retrofit.create(Bakingapi.class);
        Call<ArrayList<RecipeCake>> arrayListCall=api.getRecipes();
        arrayListCall.enqueue(new Callback<ArrayList<RecipeCake>>() {
            @Override
            public void onResponse(Call<ArrayList<RecipeCake>> call, Response<ArrayList<RecipeCake>> response) {
                if (response.code()==200){
                    list=response.body();
                    rAdapter=new RecipecakeAdapter(getBaseContext(),response.body());
                    recyclerView.setAdapter(rAdapter);
                    rAdapter.setOnItemClickListener(onItemClickListener);
                }
            }

            @Override
            public void onFailure(Call<ArrayList<RecipeCake>> call, Throwable t) {

            }
        });

    }
}
