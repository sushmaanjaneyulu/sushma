package com.example.welcome.cakebakingapp;

/**
 * Created by welcome on 6/13/2018.
 */

public class BakingData {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BakingData(String name){
        this.name=name;
    }

}
