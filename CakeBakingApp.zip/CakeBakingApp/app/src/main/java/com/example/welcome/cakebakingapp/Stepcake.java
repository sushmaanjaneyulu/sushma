package com.example.welcome.cakebakingapp;

import com.google.gson.annotations.Expose;

import org.parceler.Parcel;

/**
 * Created by welcome on 6/12/2018.
 */
@Parcel
public class Stepcake {

    @Expose
    public Integer id;
    @Expose
    public String shortDescription;
    @Expose
    public String description;
    @Expose
    public String videoURL;
    @Expose
    public String thumbnailURL;
}
