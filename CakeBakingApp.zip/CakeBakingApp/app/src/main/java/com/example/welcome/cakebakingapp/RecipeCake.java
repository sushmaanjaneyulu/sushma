package com.example.welcome.cakebakingapp;

import com.google.gson.annotations.Expose;

import org.parceler.Parcel;

import java.util.List;

/**
 * Created by welcome on 6/12/2018.
 */
@Parcel
public class RecipeCake {

    @Expose
    public Integer id;
    @Expose
    public String name;
    @Expose
    public List<BakingIngredients> ingredients=null;
    @Expose
    public List<Stepcake> steps=null;
    @Expose
    public String image;
}
