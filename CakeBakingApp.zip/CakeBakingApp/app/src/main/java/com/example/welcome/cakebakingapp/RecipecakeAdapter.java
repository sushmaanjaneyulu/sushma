package com.example.welcome.cakebakingapp;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Bitmap;
import android.content.DialogInterface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.media.MediaMetadataRetriever;
import android.support.annotation.RequiresApi;
import android.support.v7.widget.RecyclerView;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;
import android.util.Log;
import android.graphics.Color;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.TextView;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by welcome on 6/12/2018.
 */

public class RecipecakeAdapter extends RecyclerView.Adapter<RecipecakeAdapter.ViewHolder>{

    Context context;
    OnItemClickListener clickListener;
    private ArrayList<RecipeCake> recipes;

    public RecipecakeAdapter(Context context, ArrayList<RecipeCake> body) {

        this.context=context;
        this.recipes=body;
    }

    private static Bitmap retriveVideoFrame(String videoPath)throws Throwable{
        Bitmap bitmap=null;
        MediaMetadataRetriever mediaMetadataRetriever=null;
        try {
            mediaMetadataRetriever=new MediaMetadataRetriever();
            if (Build.VERSION.SDK_INT>=14){
                mediaMetadataRetriever.setDataSource(videoPath,new HashMap<String, String>());
            }else {
                mediaMetadataRetriever.setDataSource(videoPath);
            }
            bitmap=mediaMetadataRetriever.getFrameAtTime();
        }catch (Exception e){
            e.printStackTrace();
            throw new Throwable("Exception in retriveVideoFrame(String videoPath)" + e.getMessage());
        }
        finally {
            if (mediaMetadataRetriever!=null){
                mediaMetadataRetriever.release();
            }
        }
        return null;
    }

    @Override
    public RecipecakeAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.recipe_cards_list,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {

        final RecipeCake recipe=recipes.get(position);
        holder.recipeName.setText(recipe.name);
        Picasso.with(context).load("https://banner2.kisspng.com/20171128/4b2/birthday-cake-png-clipart-picture-5a1cefd5496f32.0493067515118458453008.jpg").into(holder.imageView);

    }


    public void setOnItemClickListener( final OnItemClickListener onItemClickListener) {

        this.clickListener=onItemClickListener;
    }

    public interface OnItemClickListener{
        void onItemClick(View view,int position);
    }

    @Override
    public int getItemCount() {
        return recipes.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        @BindView(R.id.recipeName)
        public TextView recipeName;
        ImageView imageView;
        public ViewHolder(View itemView) {
            super(itemView);
            imageView=(ImageView)itemView.findViewById(R.id.recipeImageId);
            ButterKnife.bind(this,itemView);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {

            if (clickListener!=null){
                clickListener.onItemClick(itemView,getPosition());
            }

        }
    }
}
