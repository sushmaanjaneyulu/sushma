package com.example.welcome.cakebakingapp;

import android.app.LauncherActivity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import com.example.welcome.cakebakingapp.dummy.DummyContent;

import org.parceler.Parcels;

import java.util.List;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;

public class ItemListActivity extends AppCompatActivity {
    @BindView(R.id.toolbar)Toolbar toolbar;
    @BindView(R.id.item_list)View rv;
    @BindString(R.string.ingredients)String ingredientsText;

    private boolean mTwoPane;
    private Intent i;
    private String title;
    private List<Stepcake> steps;
    private List<BakingIngredients> inList;
    private int stepListSize;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_list);
        ButterKnife.bind(this);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle(getTitle());
        ActionBar actionBar=getSupportActionBar();
        if (actionBar!=null){
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        i=getIntent();
        if (i.getExtras()!=null){
            title=i.getStringExtra("title");
            steps= Parcels.unwrap(i.getParcelableExtra("steps"));
            inList=Parcels.unwrap(i.getParcelableExtra("ingredients"));
            toolbar.setTitle(title);
            stepListSize=(savedInstanceState!=null)? savedInstanceState.getInt("stepsListSize"):steps.size();

            if (steps.size()==stepListSize){
                Stepcake step=new Stepcake();
                step.shortDescription=ingredientsText;
                step.id=-1;
                steps.add(0,step);

            }
        }
        setupRecyclerView((RecyclerView) rv);

        if (findViewById(R.id.item_detail_container)!=null){
            mTwoPane=true;
        }


        /*FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });*/



        /*View recyclerView = findViewById(R.id.item_list);
        assert recyclerView != null;
        setupRecyclerView((RecyclerView) recyclerView);*/
    }

    private void setupRecyclerView(@NonNull RecyclerView recyclerView) {
        recyclerView.setAdapter(new SimpleItemRecyclerViewAdapter(steps));
    }

    public class SimpleItemRecyclerViewAdapter
            extends RecyclerView.Adapter<SimpleItemRecyclerViewAdapter.ViewHolder> {

        private final List<Stepcake> mValues;

        public SimpleItemRecyclerViewAdapter(List<Stepcake> steps) {

            mValues=steps;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view=LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_list_content,parent,false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(final ViewHolder holder, int position) {
            holder.mItem=mValues.get(position);
            holder.contentView.setText(mValues.get(position).shortDescription);
            if (holder.mItem.shortDescription==ingredientsText){
                holder.contentView.setTextColor(Color.argb(255,0,0,255));
            }
            holder.mView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mTwoPane){
                        Bundle bundle=new Bundle();
                        bundle.putString("shortDescription",holder.mItem.shortDescription);
                        bundle.putInt("id",holder.mItem.id);
                        if (holder.mItem.shortDescription==ingredientsText){
                            toolbar.setTitle(ingredientsText);
                            bundle.putParcelable("ingredients",i.getParcelableExtra("ingredients"));
                        }else {
                            bundle.putString("description",holder.mItem.description);
                            bundle.putString("videoURL",holder.mItem.videoURL);
                            bundle.putString("thumbnailURL",holder.mItem.thumbnailURL);
                        }
                        ItemDetailFragment fragment=new ItemDetailFragment();
                        fragment.setArguments(bundle);
                        getSupportFragmentManager().beginTransaction().replace(R.id.item_detail_container,fragment).commit();
                    }else {
                        Context context=v.getContext();
                        Intent intent=new Intent(context,ItemDetailActivity.class);
                        intent.putExtra("shortDescription",holder.mItem.shortDescription);
                        if (holder.mItem.shortDescription==ingredientsText){
                            intent.putExtra("ingredients",Parcels.wrap(inList));
                        }else {
                            intent.putExtra("description",holder.mItem.description);
                            intent.putExtra("videoURL",holder.mItem.videoURL);
                            intent.putExtra("thumbnailURL",holder.mItem.thumbnailURL);
                        }
                        context.startActivity(intent);
                    }
                }
            });

        }

        @Override
        public int getItemCount() {
            return mValues.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {

            public final View mView;
            public Stepcake mItem;
            @BindView(R.id.content)TextView contentView;
            public ViewHolder(View itemView) {
                super(itemView);
                mView=itemView;
                ButterKnife.bind(this,itemView);
            }
        }
    }
}
