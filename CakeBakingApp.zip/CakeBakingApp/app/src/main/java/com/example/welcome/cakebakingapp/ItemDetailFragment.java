package com.example.welcome.cakebakingapp;

import android.annotation.TargetApi;
import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.support.v7.widget.Toolbar;
import android.widget.Toast;

import com.google.android.exoplayer2.DefaultLoadControl;
import com.google.android.exoplayer2.DefaultRenderersFactory;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.trackselection.AdaptiveTrackSelection;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelection;
import com.google.android.exoplayer2.ui.SimpleExoPlayerView;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSourceFactory;
import com.google.android.exoplayer2.util.Util;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;
import android.util.Log;

import org.parceler.Parcels;

import java.util.List;

import butterknife.BindBool;
import butterknife.BindView;
import butterknife.ButterKnife;


public class ItemDetailFragment extends Fragment {
    private static final DefaultBandwidthMeter BANDWIDTH_METER=new DefaultBandwidthMeter();
    @BindView(R.id.stepList)
    LinearLayout stepList;
    @BindView(R.id.video_view)
    SimpleExoPlayerView exoPlayerView;
    @BindView(R.id.itemDetails_list) View rv;
    @BindView(R.id.itemImage) ImageView thumnailImage;
    @BindBool(R.bool.isTablet)boolean isTablet;
    String item,mDes,vURL,iURL;
    private List<BakingIngredients> ingredients;
    private Activity activity;
    private SimpleExoPlayer playerView;
    String thumbnailURL;
    long playBackPosition;
    int currentWindow;
    boolean playWhenReady=true,isIngredients=false;
    @BindView(R.id.itemdetail) TextView details;
    public ItemDetailFragment() {
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activity=this.getActivity();
        if (savedInstanceState!=null){
            playBackPosition=savedInstanceState.getLong("position",0);
        }

        if (getArguments().containsKey("shortDescription")) {
            // Load the dummy content specified by the fragment
            // arguments. In a real-world scenario, use a Loader
            // to load content from a content provider.
            item = getArguments().getString("shortDescription");
            activity.setTitle(item);
            isIngredients=true;
            Toolbar toolbar=activity.findViewById(R.id.toolbar);
            if (toolbar!=null){
                toolbar.setTitle(item);
            }
            }
        }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.item_detail, container, false);
        ButterKnife.bind(this, rootView);
        iURL = getArguments().getString("thumbnailURL");
        //Toast.makeText(activity,iURL, Toast.LENGTH_SHORT).show();

        if (getArguments().containsKey("ingredients")) {
            ingredients = Parcels.unwrap(getArguments().getParcelable("ingredients"));
            setRecyclerView((RecyclerView) rv);
            stepList.setVisibility(View.GONE);
            exoPlayerView.setVisibility(View.GONE);
            releasePlayer();
        } else {

            if (savedInstanceState != null) {
                playBackPosition = savedInstanceState.getLong("position");
                playWhenReady = savedInstanceState.getBoolean("ready");
            }
            mDes = getArguments().getString("description");
            vURL = getArguments().getString("videoURL");
            Log.i("videoUrl", vURL.toString());

            rv.setVisibility(View.GONE);


            if (!vURL.toString().contains("https")) {

                if (iURL.isEmpty()) {


                    thumnailImage.setVisibility(View.VISIBLE);
                } else {
                   /*Picasso.with(getContext()).load(R.drawable.bakerycake).into(thumnailImage);
                   thumnailImage.setVisibility(View.VISIBLE);*/
                        if(iURL.endsWith("mp4")) {
                            if (playerView == null) {

                                TrackSelection.Factory videoFactory = new AdaptiveTrackSelection.Factory(BANDWIDTH_METER);
                                playerView = ExoPlayerFactory.newSimpleInstance(new DefaultRenderersFactory(getContext()), new DefaultTrackSelector(videoFactory), new DefaultLoadControl());
                                exoPlayerView.setPlayer(playerView);
                                playerView.seekTo(currentWindow, playBackPosition);
                                exoPlayerView.setVisibility(View.GONE);

                            }
                            MediaSource source = buildSource(Uri.parse(iURL));
                            playerView.prepare(source, false, false);
                            playerView.setPlayWhenReady(playWhenReady);
                            exoPlayerView.setVisibility(View.VISIBLE);
                        }
                        else
                            Picasso.with(getContext()).load(iURL).into(thumnailImage);
                    }

                }else{
                    if (!isTablet) {
                        if (activity.getResources().getConfiguration().orientation == 2) {
                            exoPlayerView.setBackgroundColor(Color.parseColor("black"));
                            stepList.setVisibility(View.GONE);
                            exoPlayerView.setVisibility(View.VISIBLE);
                        }
                    }
                    initializePlayer();
                }
                details.setText(mDes);
            }

            // Show the dummy content as text in a TextView.

            return rootView;
        }

    private void setRecyclerView(RecyclerView rv) {
        rv.setAdapter(new SimpleViewAdapter(ingredients));
    }

    private void initializePlayer() {

        if (playerView==null){
            /*TrackSelection.Factory videoFactory=new AdaptiveVideoTrackSelection.Factory(BANDWIDTH_METER);
            playerView=ExoPlayerFactory.newSimpleInstance(new );
            exoPlayerView.setPlayer(playerView);
            playerView.seekTo(currentWindow,playBackPosition);*/
            TrackSelection.Factory videoFactory=new AdaptiveTrackSelection.Factory(BANDWIDTH_METER);
            playerView=ExoPlayerFactory.newSimpleInstance(new DefaultRenderersFactory(getContext()),new DefaultTrackSelector(videoFactory),new DefaultLoadControl());
            exoPlayerView.setPlayer(playerView);
            playerView.seekTo(currentWindow,playBackPosition);
            exoPlayerView.setVisibility(View.GONE);

        }
        MediaSource source=buildSource(Uri.parse(vURL));
        playerView.prepare(source,false,false);
        playerView.setPlayWhenReady(playWhenReady);
        exoPlayerView.setVisibility(View.VISIBLE);
    }

    @Override
    public void onStart() {
        super.onStart();
        if (Util.SDK_INT>23){
            if (!isIngredients){
                initializePlayer();
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (Util.SDK_INT>23 || playerView==null){
            if (!isIngredients){
                initializePlayer();
            }
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if (Util.SDK_INT<=23){
            if (playerView!=null){
                releasePlayer();
            }
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        if (Util.SDK_INT>23){
            releasePlayer();
        }
    }

    private void releasePlayer() {

        if (playerView!=null){
            playBackPosition=playerView.getCurrentPosition();
            currentWindow=playerView.getCurrentWindowIndex();
            playWhenReady=playerView.getPlayWhenReady();
            playerView.release();
        }
    }

    private MediaSource buildSource(Uri parse){
        DataSource.Factory factory=new DefaultHttpDataSourceFactory("useragent",BANDWIDTH_METER);
        return new ExtractorMediaSource(parse,factory,new DefaultExtractorsFactory(),null,null);
    }


     class SimpleViewAdapter extends RecyclerView.Adapter<SimpleViewAdapter.MyViewHolder>{
       private final List<BakingIngredients> value;
       public SimpleViewAdapter(List<BakingIngredients> ingredient){
           this.value=ingredient;
       }

         @Override
         public SimpleViewAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
             return new MyViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list_content,parent,false));
         }

         @Override
         public void onBindViewHolder(SimpleViewAdapter.MyViewHolder holder, int position) {

            holder.ingredients=value.get(position);
            holder.contentTv.setText(value.get(position).quantity +" "+ value.get(position).ingredient);
         }

         @Override
         public int getItemCount() {
             return value.size();
         }

         public class MyViewHolder extends RecyclerView.ViewHolder {

           public final View mView;

           public BakingIngredients ingredients;
           @BindView(R.id.content)TextView contentTv;
             public MyViewHolder(View itemView) {
                 super(itemView);
                 mView=itemView;
                 ButterKnife.bind(this,itemView);
             }
             public String toString(){
                 return super.toString() + " '" + contentTv.getText() + "'";
             }
         }
     }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putLong("position",playBackPosition);
        if (playerView!=null){
            outState.putLong("position",playerView.getCurrentPosition());
            outState.putBoolean("ready",playerView.getPlayWhenReady());
        }
    }
}
