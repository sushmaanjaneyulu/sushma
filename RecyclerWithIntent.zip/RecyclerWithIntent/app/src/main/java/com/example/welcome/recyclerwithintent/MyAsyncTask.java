package com.example.welcome.recyclerwithintent;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by welcome on 5/10/2018.
 */

public class MyAsyncTask extends AsyncTask<String, Void, String> {

    RecyclerView recyclerView;
    ProgressDialog progressDialog;
    Context context;
    static GridLayoutManager gmanager;

    ArrayList<Pojo> arrayList = new ArrayList<>();

    public MyAsyncTask(MainActivity mainActivity, RecyclerView recyclerView) {
        this.context = mainActivity;
        this.recyclerView = recyclerView;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        progressDialog = new ProgressDialog(context);
        progressDialog.setTitle("please wait");
        progressDialog.show();
    }

    @Override
    protected String doInBackground(String... strings) {

        String url = strings[0];
        StringBuilder result = new StringBuilder();
        try {
            URL buildUrl = new URL(url);
            HttpURLConnection connection = (HttpURLConnection) buildUrl.openConnection();
            InputStream in = connection.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String str = "";
            while (str != null) {
                str = br.readLine();
                result.append(str);

            }
            return result.toString();

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }


    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);

        try {
            JSONObject jsonObject = new JSONObject(s);
            JSONArray res = jsonObject.getJSONArray("results");
            for (int i = 0; i < res.length(); i++) {
                JSONObject re = res.getJSONObject(i);

                String name = re.getString("title");

                Double pop = re.getDouble("popularity");

                String otit = re.getString("original_title");
                String language = re.getString("original_language");
                String overview = re.getString("overview");
                Boolean adult = re.getBoolean("adult");
                String reldate = re.getString("release_date");
                String back="https://image.tmdb.org/t/p/w500"+re.getString("backdrop_path");
                String img = "https://image.tmdb.org/t/p/w500"+re.getString("poster_path");

                Boolean vid = re.getBoolean("video");
                Double vavg = re.getDouble("vote_average");
                Double vcount = re.getDouble("vote_count");
                Double id = re.getDouble("id");

                Pojo p = new Pojo(name, pop,otit,language,overview,adult,reldate,back,vid,vavg,vcount,id,img);
                arrayList.add(p);


            }
        } catch (JSONException e) {
            e.printStackTrace();

        }
        gmanager=new GridLayoutManager(context,2);

        recyclerView.setLayoutManager(gmanager);
        recyclerView.setAdapter(new MyAdapter(context,arrayList));
        recyclerView.scrollToPosition(MainActivity.scrValue);

        progressDialog.dismiss();


    }
}
