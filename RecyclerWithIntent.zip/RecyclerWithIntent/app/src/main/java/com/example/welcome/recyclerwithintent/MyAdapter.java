package com.example.welcome.recyclerwithintent;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.welcome.recyclerwithintent.Favdata.FavContract;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by welcome on 5/7/2018.
 */

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {
    Context context;
     ArrayList<Pojo> arrlist;

    public MyAdapter(Context context, ArrayList<Pojo> List) {
        this.context=context;
        arrlist=List;
    }



    @Override
    public MyAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View v= LayoutInflater.from(context).inflate(R.layout.activity_imagelist,parent,false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(MyAdapter.MyViewHolder holder , int position) {

      Pojo pj=arrlist.get(position);

       holder.title.setText(pj.getTitle());

       Picasso.with(context).load(pj.getImage()).placeholder(R.mipmap.ic_launcher).into(holder.img);
    }

    @Override
    public int getItemCount() {
        return arrlist.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        ImageView img;

        public MyViewHolder(View itemView) {
            super(itemView);
            title=(TextView) itemView.findViewById(R.id.titleID);
            img=(ImageView) itemView.findViewById(R.id.imgId);

            Uri myUri= FavContract.FavEntryMovies.CONTENT_URI;

            Log.d("MyAdapter",myUri.toString());

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int imgarray=getAdapterPosition();
                    Pojo position=arrlist.get(imgarray);
                   // Toast.makeText(context, ""+imgarray, Toast.LENGTH_SHORT).show();
                    String[] str=new String[10];
                    str[0]=arrlist.get(imgarray).getOriginal_title();
                    str[1]=position.getImage();
                    str[2]=arrlist.get(imgarray).getRelease_date();
                    str[3]=position.getBackdrop_path();

                    //Toast.makeText(context, ""+str[3], Toast.LENGTH_SHORT).show();

                    str[4]=arrlist.get(imgarray).getOverview();
                    str[5]= String.valueOf(arrlist.get(imgarray).getVote_average());
                    str[6]= String.valueOf(arrlist.get(imgarray).getId());
                    Intent intent=new Intent(context,SecondActivity.class);
                    intent.putExtra("key",str);
                    Log.i("array",str.toString());

                   v.getContext().startActivity(intent);
                }
            });
        }
    }
}
