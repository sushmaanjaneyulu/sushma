package com.example.welcome.recyclerwithintent.Favdata;

import android.content.ContentResolver;
import android.net.Uri;
import android.provider.BaseColumns;

/**
 * Created by welcome on 5/23/2018.
 */

public class FavContract {
    public static final String CONTENT_AUTHORITY="com.example.welcome.recyclerwithintent";
    public static final Uri BASE_CONTENT_URI=Uri.parse("content://" + CONTENT_AUTHORITY);
    public static final String PATH_MOVIES="movies";

    private FavContract(){

    }

    public static final class FavEntryMovies implements BaseColumns{
        public static final String TABLE_NAME="favourite";
        public static final String MOVIE_ID="MOVIE_ID";
        public static final String TITLE="title";
        public static final String RELEASE_DATE="releaseDate";
        public static final String RATING="rating";
        public static final String PLOT_SYN="overview";
        public static final String POSTER_PATH="posterPath";
        public static final String BACKDROP_PATH="backdropPath";

        public static final Uri CONTENT_URI=BASE_CONTENT_URI.buildUpon().appendPath(PATH_MOVIES).build();

        public static final String CONTENT_TYPE= ContentResolver.CURSOR_DIR_BASE_TYPE + "/" + CONTENT_AUTHORITY + "/" + PATH_MOVIES;

        public static final String CONTENT_ITEM_TYPE=ContentResolver.CURSOR_ITEM_BASE_TYPE + "/" +CONTENT_AUTHORITY + "/" + PATH_MOVIES;



      public static Uri BuildUri(long id){
          return  CONTENT_URI.buildUpon().appendPath(Long.toString(Long.parseLong(MOVIE_ID))).build();
      }
    }
}
