package com.example.welcome.recyclerwithintent.Favdata;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by welcome on 5/17/2018.
 */

public class FavouriteDbHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "wishlistDb";
    private static final int VERSION = 7;
    private static final String LOGTAG = "WISHLIST";
    Context context;


    SQLiteOpenHelper sqLiteOpenHelper;
    SQLiteDatabase sqLiteDatabase;

    public FavouriteDbHelper(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        final String FAV_TABLE = "CREATE TABLE " + FavContract.FavEntryMovies.TABLE_NAME + "(" +

                FavContract.FavEntryMovies.MOVIE_ID + " INTEGER UNIQUE," +
                FavContract.FavEntryMovies.TITLE + " TEXT," +
                FavContract.FavEntryMovies.RELEASE_DATE + " TEXT," +
                FavContract.FavEntryMovies.POSTER_PATH + " TEXT," +
                FavContract.FavEntryMovies.PLOT_SYN + " TEXT," +
                FavContract.FavEntryMovies.RATING + " REAL," +
                FavContract.FavEntryMovies.BACKDROP_PATH + " TEXT)" + ";";
        db.execSQL(FAV_TABLE);
        Log.i("table creation", db.toString());

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + FavContract.FavEntryMovies.TABLE_NAME);
        onCreate(db);
    }

    public boolean isFav(String favourites) {

       // Toast.makeText(context, "MovieID="+favourites, Toast.LENGTH_SHORT).show();
        SQLiteDatabase database = getWritableDatabase();

        String str = "SELECT * FROM " + FavContract.FavEntryMovies.TABLE_NAME + " WHERE " + FavContract.FavEntryMovies.MOVIE_ID + " = ? ";

        Cursor cursor = database.rawQuery(str, new String[]{String.valueOf(favourites)});

        boolean isFav = true;

        if (cursor.moveToFirst()) {

            isFav = false;

            int count = 0;

            while (cursor.moveToNext()) {
                count++;
            }
        }
        cursor.close();
        database.close();
        return isFav;
    }
}


