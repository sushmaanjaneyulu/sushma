package com.example.welcome.recyclerwithintent;

/**
 * Created by welcome on 5/7/2018.
 */

public class Pojo {
    double id, vote_count, vote_average, popularity;
    String title, image, poster_path;
    String original_path;
    String release_date;
    String original_title;
    String backdrop_path;
    String overview;
    String original_language;
    boolean adult, video;

    public Pojo(String name, Double pop, String otit, String language, String overview, Boolean adult, String reldate, String back, Boolean vid, Double vavg, Double vcount, Double id, String img) {
        this.title = name;
        this.vote_count = vcount;
        this.id = id;
        this.video = vid;
        this.vote_average = vavg;
        this.popularity = pop;
        this.original_language = language;
        this.original_title = otit;
        this.release_date = reldate;
        this.backdrop_path = back;
        this.image = img;
        this.adult = adult;
        this.overview = overview;

    }

    public Pojo(double id, double vavg, String img, String overview, String name, String reldate, String back) {

        this.id=id;
        this.vote_average=vavg;
        this.image=img;
        this.overview=overview;
        this.title=name;
        this.release_date=reldate;
        this.backdrop_path=back;
    }

   /* public Pojo(double id, double vavg, String img, String overview, String name, String reldate, String back) {

        this.id=id;
        this.vote_average=vavg;
        this.image=img;
        this.overview=overview;
        this.title=name;
        this.release_date=reldate;
        //this.backdrop_path=back;
    }*/




    public double getId() {
        return id;
    }

    public void setId(double id) {
        this.id = id;
    }

    public double getVote_count() {
        return vote_count;
    }

    public void setVote_count(double vote_count) {
        this.vote_count = vote_count;
    }

    public double getVote_average() {
        return vote_average;
    }

    public void setVote_average(double vote_average) {
        this.vote_average = vote_average;
    }

    public double getPopularity() {
        return popularity;
    }

    public void setPopularity(double popularity) {
        this.popularity = popularity;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getPoster_path() {
        return poster_path;
    }

    public void setPoster_path(String poster_path) {
        this.poster_path = poster_path;
    }

    public String getOriginal_path() {
        return original_path;
    }

    public void setOriginal_path(String original_path) {
        this.original_path = original_path;
    }

    public String getRelease_date() {
        return release_date;
    }

    public void setRelease_date(String release_date) {
        this.release_date = release_date;
    }

    public String getOriginal_title() {
        return original_title;
    }

    public void setOriginal_title(String original_title) {
        this.original_title = original_title;
    }

    public String getBackdrop_path() {
        return backdrop_path;
    }

    public void setBackdrop_path(String backdrop_path) {
        this.backdrop_path = backdrop_path;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public String getOriginal_language() {
        return original_language;
    }

    public void setOriginal_language(String original_language) {
        this.original_language = original_language;
    }

    public boolean isAdult() {
        return adult;
    }

    public void setAdult(boolean adult) {
        this.adult = adult;
    }

    public boolean isVideo() {
        return video;
    }

    public void setVideo(boolean video) {
        this.video = video;
    }
}

