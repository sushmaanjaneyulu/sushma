package com.example.welcome.recyclerwithintent.trailer;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.welcome.recyclerwithintent.R;

import java.util.ArrayList;

/**
 * Created by welcome on 5/21/2018.
 */

public class TrailerVideoAdapter extends RecyclerView.Adapter<TrailerVideoAdapter.MyViewHolder> {

    Context context;
    ArrayList<TrailerVideoPojo> trailerList;

    public TrailerVideoAdapter(Context context,ArrayList<TrailerVideoPojo> trailerList){
        this.context=context;
        this.trailerList=trailerList;

    }
    @Override
    public TrailerVideoAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(context).inflate(R.layout.trailer_video_rows,parent,false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(TrailerVideoAdapter.MyViewHolder holder, int position) {
      holder.trailerTv.setText(trailerList.get(position).getVideoType());

    }

    @Override
    public int getItemCount() {
        return trailerList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView trailerTv;
        public MyViewHolder(View itemView) {
            super(itemView);
            trailerTv=(TextView)itemView.findViewById(R.id.trailer_id);
            itemView.setOnClickListener(this);

        }

        @Override
        public void onClick(View v) {
            v.getContext().startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("http://www.youtube.com/watch?v="+""+trailerList.get(getAdapterPosition()).getVideoKey())));
        }
    }
}
