package com.example.welcome.recyclerwithintent;

import android.content.Context;
import android.content.res.Configuration;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.example.welcome.recyclerwithintent.Favdata.FavContract;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    String Key="storeState";
    static String vState="";
    private String scrKey="scrKey";
    static int scrValue;
    public static RecyclerView recyclerView;
    CoordinatorLayout coordinatorLayout;
    Snackbar snackbar;
    String url="http://api.themoviedb.org/3/movie/popular?api_key=" + API_KEY;
    String url1="http://api.themoviedb.org/3/movie/top_rated?api_key=" + API_KEY;

    private ArrayList<Pojo> arrayList;
    private MyAdapter adapter;
    public static final String API_KEY = BuildConfig.API_KEY;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        coordinatorLayout=(CoordinatorLayout)findViewById(R.id.coordinate_id);
        if (isConnected()){
            snackbar=Snackbar.make(coordinatorLayout,"connected to internet",Snackbar.LENGTH_LONG);
            View view=snackbar.getView();
            view.setBackgroundColor(this.getResources().getColor(R.color.colorPrimary));
            snackbar.show();

            if (savedInstanceState!=null){

                if (savedInstanceState.containsKey(Key)){
                    String a=savedInstanceState.getString(Key);
                    scrValue=savedInstanceState.getInt(scrKey);
                    if (a.equals("popular")){
                        MyAsyncTask task=new MyAsyncTask(this,recyclerView);

                        task.execute(url);
                    }else if (a.equals("top_rated")){

                        MyAsyncTask task=new MyAsyncTask(this,recyclerView);
                        task.execute(url1);
                    }else if(a.equals("favourites")){
                        ArrayList<Pojo> favourites=getFavouriteMovies();
                        MainActivity.recyclerView.setLayoutManager(new GridLayoutManager(this,numberOfColumns()));
                        MainActivity.recyclerView.setAdapter(new MyAdapter(this,favourites));

                    }
                    else {
                        MyAsyncTask task=new MyAsyncTask(this,recyclerView);
                        task.execute(url);
                    }

                }else {
                    MyAsyncTask task=new MyAsyncTask(this,recyclerView);
                    task.execute(url);
                }
            }else {
                MyAsyncTask task=new MyAsyncTask(this,recyclerView);
                task.execute(url);
            }

        }else {
            snackbar=Snackbar.make(coordinatorLayout,"please check connection",Snackbar.LENGTH_LONG);
            View view=snackbar.getView();
            view.setBackgroundColor(this.getResources().getColor(R.color.colorPrimary));
            snackbar.show();
        }
    }
    public boolean isConnected(){
        boolean connected=false;
        try{ ConnectivityManager connectivityManager=(ConnectivityManager)getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo info=connectivityManager.getActiveNetworkInfo();
            connected=info!=null&&info.isAvailable()&&info.isConnected();
            return connected;
        }catch (Exception e){
            Log.e("connection exception",e.getMessage());
        }
        return connected;

    }

    private int numberOfColumns() {
        DisplayMetrics displayMetrics=new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int widthDivider=400;
        int width=displayMetrics.widthPixels;
        int columns=width/widthDivider;
        if (columns<2)
            return 2;
        return columns;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu, menu);
        return true;
    }

    ArrayList<Pojo> getFavouriteMovies(){

        String name,otit,language,overview,back,img,reldate;
        boolean adult,vid;
        double vavg,vcount,pop,id;
        Cursor infoMovie=getContentResolver().query(FavContract.FavEntryMovies.CONTENT_URI,null,null,null,null);
        ArrayList<Pojo> pojoFav=new ArrayList<>();
        if (infoMovie.getCount()>0){

            if(infoMovie.moveToFirst()){

                do {
                    id=infoMovie.getInt(0);
                    vavg=infoMovie.getDouble(5);
                    img=infoMovie.getString(3);
                    overview=infoMovie.getString(4);
                    name=infoMovie.getString(1);
                    reldate=infoMovie.getString(2);
                    back=infoMovie.getString(6);
                    Pojo p=new Pojo(id,vavg,img,overview,name,reldate,back);
                    pojoFav.add(p);
                }while(infoMovie.moveToNext());

            }

        }else {

            Toast.makeText(this, "no favourites", Toast.LENGTH_SHORT).show();
        }

        return pojoFav;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.id_popular:
                scrValue=0;

                if (isConnected()){

                    vState="popular";
                    snackbar=Snackbar.make(coordinatorLayout,"connected to internet",Snackbar.LENGTH_LONG);
                    View view=snackbar.getView();
                    view.setBackgroundColor(this.getResources().getColor(R.color.colorPrimary));
                    snackbar.show();

                    MyAsyncTask asyncTask1 = new MyAsyncTask(this, recyclerView);

                    asyncTask1.execute(url);

                }else {

                   // alert.showAlertDialog(MainActivity.this,"Fail","Internet connection is not available",false);
                    snackbar=Snackbar.make(coordinatorLayout,"please check connection",Snackbar.LENGTH_LONG);
                    View view=snackbar.getView();
                    view.setBackgroundColor(this.getResources().getColor(R.color.colorPrimary));
                    snackbar.show();
                }
                break;
            case R.id.id_rating:
                scrValue=0;

                if (isConnected()){

                    vState="top_rated";
                    snackbar=Snackbar.make(coordinatorLayout,"connected to internet",Snackbar.LENGTH_LONG);
                    View view=snackbar.getView();
                    view.setBackgroundColor(this.getResources().getColor(R.color.colorPrimary));
                    snackbar.show();

                    MyAsyncTask asyncTask2 = new MyAsyncTask(this, recyclerView);

                    asyncTask2.execute(url1);
                }else {

                    snackbar=Snackbar.make(coordinatorLayout,"please check connection",Snackbar.LENGTH_LONG);
                    View view=snackbar.getView();
                    view.setBackgroundColor(this.getResources().getColor(R.color.colorPrimary));
                    snackbar.show();
                }
                break;

            case R.id.setting:

                vState="favourites";

                ArrayList<Pojo> favList=new ArrayList<>();

                favList=getFavouriteMovies();

                if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
                    recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
                } else {
                    recyclerView.setLayoutManager(new GridLayoutManager(this, 4));
                }
                recyclerView.setItemAnimator(new DefaultItemAnimator());
                recyclerView.setAdapter(new MyAdapter(this,favList));
                break;

        }

        return true;
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(Key,vState);
        scrValue=MyAsyncTask.gmanager.findFirstVisibleItemPosition();
        outState.putInt(scrKey,scrValue);
    }
}




