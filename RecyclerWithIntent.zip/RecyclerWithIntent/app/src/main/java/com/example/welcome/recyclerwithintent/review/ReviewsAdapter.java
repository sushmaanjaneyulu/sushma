package com.example.welcome.recyclerwithintent.review;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.welcome.recyclerwithintent.R;

import java.util.ArrayList;

/**
 * Created by welcome on 5/22/2018.
 */

public class ReviewsAdapter extends RecyclerView.Adapter<ReviewsAdapter.ViewHolder> {
    ArrayList<ReviewPojo> reviewList;
    Context context;

    public ReviewsAdapter(Context context,ArrayList<ReviewPojo> rList){
        super();
        this.context=context;
        this.reviewList=rList;
    }
    @Override
    public ReviewsAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(context).inflate(R.layout.review_list,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ReviewsAdapter.ViewHolder holder, int position) {

        holder.author.setText(reviewList.get(position).getAuthor());
        holder.content.setText(reviewList.get(position).getContent());
        holder.url.setText(reviewList.get(position).getUrl());

    }

    @Override
    public int getItemCount() {
        return reviewList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView author,content,url;
        public ViewHolder(View itemView) {
            super(itemView);
            author=(TextView)itemView.findViewById(R.id.author_id);
            content=(TextView)itemView.findViewById(R.id.content_id);
            url=(TextView)itemView.findViewById(R.id.url_id);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            v.getContext().startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(reviewList.get(getAdapterPosition()).getUrl())));
        }
    }
}
