package com.example.welcome.recyclerwithintent.trailer;

/**
 * Created by welcome on 5/22/2018.
 */

public class TrailerVideoPojo {

    String videoKey;
    String videoType;

    public TrailerVideoPojo(String key, String type) {
        this.videoKey = key;
        this.videoType = type;
    }

    public String getVideoKey() {
        return videoKey;
    }

    public void setVideoKey(String videoKey) {
        this.videoKey = videoKey;
    }

    public String getVideoType() {
        return videoType;
    }

    public void setVideoType(String videoType) {
        this.videoType = videoType;
    }

}
