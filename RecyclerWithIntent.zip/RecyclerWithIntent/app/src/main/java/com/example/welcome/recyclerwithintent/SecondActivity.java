package com.example.welcome.recyclerwithintent;

import android.annotation.TargetApi;
import android.app.LoaderManager;
import android.content.AsyncTaskLoader;
import android.content.ContentValues;
import android.content.Loader;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.welcome.recyclerwithintent.Favdata.FavContract;
import com.example.welcome.recyclerwithintent.Favdata.FavouriteDbHelper;
import com.example.welcome.recyclerwithintent.review.ReviewPojo;
import com.example.welcome.recyclerwithintent.review.ReviewsAdapter;
import com.example.welcome.recyclerwithintent.trailer.TrailerVideoAdapter;
import com.example.welcome.recyclerwithintent.trailer.TrailerVideoPojo;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import static com.example.welcome.recyclerwithintent.MainActivity.API_KEY;

//import com.example.welcome.recyclerwithintent.Favdata.FavouriteDbHelper;
//import com.example.welcome.recyclerwithintent.Favdata.FavouriteDbHelper;

public class SecondActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<ArrayList<TrailerVideoPojo>> {
    Snackbar snac;
    CoordinatorLayout coordinate1;
    ArrayList<Pojo> arrlist;
    public static final int loader_id=1;
    public static final int review_id=2;
    public static RecyclerView trailer_rv;
    public static RecyclerView review_rv;
    public static String str="";
    ArrayList<TrailerVideoPojo> trailerList=new ArrayList<>();
    public static String url1="http://api.themoviedb.org/3/movie/";
    ArrayList<ReviewPojo> reviewList=new ArrayList<>();
    String url2="http://api.themoviedb.org/3/movie/";
    int[] imgarray;
    TextView title, releaseDate, date, voteAvg, avgNumber, plotSynopsis, plotDescription;
    ImageView imageView, img;
    private SQLiteDatabase db;
    private View buttonView;
    FavouriteDbHelper favouriteDbHelper=new FavouriteDbHelper(this);
    boolean favourite=true;
    int movieId;

    private Pojo fav;
    private final AppCompatActivity activity=SecondActivity.this;
    String[] movieDetails;
    private ContentValues cv;

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        String url = "http://api.themoviedb.org/3/videos/videos?api_key=API_KEY";
        trailer_rv = (RecyclerView) findViewById(R.id.rec_view);
        review_rv = (RecyclerView) findViewById(R.id.id_review_id);
        title = (TextView) findViewById(R.id.title_id);
        releaseDate = (TextView) findViewById(R.id.release_id);
        date = (TextView) findViewById(R.id.date_id);
        voteAvg = (TextView) findViewById(R.id.voteavg_id);
        avgNumber = (TextView) findViewById(R.id.voteavgnumber_id);
        plotSynopsis = (TextView) findViewById(R.id.plot_id);
        plotDescription = (TextView) findViewById(R.id.plot_data_id);
        img = (ImageView) findViewById(R.id.poster_image_id);
        imageView = (ImageView) findViewById(R.id.backdrop_image_Id);

        movieDetails = new String[10];

        movieDetails = getIntent().getStringArrayExtra("key");
        str = movieDetails[6];
        boolean connect=new MainActivity().isConnected();
        if (connect==false){

            final String s1 = movieDetails[1];
            final String s2 = movieDetails[3];



            Picasso.with(this).load(s2).placeholder(R.mipmap.ic_launcher).into(imageView);
            Log.i("backdroppath", "imgview");
            Picasso.with(this).load(s1).placeholder(R.mipmap.ic_launcher).into(img);
            Log.i("posterpath", "img");
            title.setText(movieDetails[0]);
            date.setText(movieDetails[2]);
            avgNumber.setText(movieDetails[5]);
            plotDescription.setText(movieDetails[4]);


        }else {
            Toast.makeText(this, "please check connection", Toast.LENGTH_SHORT).show();
        }

        getLoaderManager().initLoader(loader_id, null, SecondActivity.this);
        getLoaderManager().restartLoader(review_id, null, SecondActivity.this);



        final Button btn = (Button) findViewById(R.id.fav_btn);


        favourite=favouriteDbHelper.isFav(str);

        if (favourite){

            btn.setBackground(getDrawable(R.drawable.heartborder));

        }else {

            btn.setBackground(getDrawable(R.drawable.heartfull));

        }

        btn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Cursor cursor = getContentResolver().query(Uri.parse(FavContract.FavEntryMovies.CONTENT_URI +"/*"), null, FavContract.FavEntryMovies.MOVIE_ID + " LIKE ? ", new String[]{str}, null);

                Log.i("onclick", str);

                if (favourite==true){

                    ContentValues cv = new ContentValues();

                    cv.put(FavContract.FavEntryMovies.MOVIE_ID, movieDetails[6]);
                    Log.i("MovieID",movieDetails[6]);
                    cv.put(FavContract.FavEntryMovies.TITLE, movieDetails[0]);
                    cv.put(FavContract.FavEntryMovies.RATING, movieDetails[5]);
                    cv.put(FavContract.FavEntryMovies.PLOT_SYN, movieDetails[4]);
                    cv.put(FavContract.FavEntryMovies.RELEASE_DATE, movieDetails[2]);
                    cv.put(FavContract.FavEntryMovies.POSTER_PATH, movieDetails[1]);
                    cv.put(FavContract.FavEntryMovies.BACKDROP_PATH, movieDetails[3]);
                    Log.i("Fav added", cv.toString());

                    getContentResolver().insert(Uri.parse(FavContract.FavEntryMovies.CONTENT_URI+""), cv);
                    Toast.makeText(SecondActivity.this, "Added as favourite", Toast.LENGTH_SHORT).show();

                    btn.setBackground(getDrawable(R.drawable.heartborder));


                    favourite=true;



                }else {

                    getContentResolver().delete(Uri.parse(FavContract.FavEntryMovies.CONTENT_URI + "/*"), FavContract.FavEntryMovies.MOVIE_ID + " = ? ", new String[]{str});

                    Toast.makeText(SecondActivity.this, "remove fav", Toast.LENGTH_SHORT).show();

                    btn.setBackground(getDrawable(R.drawable.heartfull));

                    favourite=false;

                }



            }
        });
    }


    @Override
    public Loader<ArrayList<TrailerVideoPojo>> onCreateLoader(int id, Bundle args) {
        switch (id) {
            case loader_id:
                return new AsyncTaskLoader<ArrayList<TrailerVideoPojo>>(this) {
                    @Override
                    public ArrayList<TrailerVideoPojo> loadInBackground() {
                        StringBuilder result = new StringBuilder();
                        Uri uri= Uri.parse(url1).buildUpon().appendPath(str)
                                .appendPath("videos")
                                .appendQueryParameter("api_key",API_KEY).build();
                        URL url=null;
                        Log.d("videosURL",uri.toString());
                        try {
                            url=new URL(uri.toString());
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        }

                        try {
                            HttpURLConnection connection = (HttpURLConnection)url.openConnection();
                            connection.setRequestMethod("GET");
                            InputStream in = connection.getInputStream();
                            BufferedReader br = new BufferedReader(new InputStreamReader(in));
                            String str = "";
                            while (str != null) {
                                str = br.readLine();
                                result.append(str).append("\n");
                                in.close();
                            }
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        Log.d("data-->",result.toString());
                        if (result != null) {
                            try {
                                JSONObject jsonObject = new JSONObject(result.toString());
                                JSONArray trailerRes = jsonObject.getJSONArray("results");
                                for (int i = 0; i < trailerRes.length(); i++) {
                                    JSONObject re = trailerRes.getJSONObject(i);
                                    String key = re.getString("key");
                                    String type = re.getString("type");
                                    TrailerVideoPojo trailerVideoPojo = new TrailerVideoPojo(key, type);
                                    trailerList.add(trailerVideoPojo);
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        return trailerList;
                    }

                    @Override
                    protected void onStartLoading() {
                        super.onStartLoading();
                        forceLoad();
                    }
                };
            case review_id:
                return new AsyncTaskLoader<ArrayList<TrailerVideoPojo>>(this) {
                    @Override
                    public ArrayList<TrailerVideoPojo> loadInBackground() {
                        StringBuilder result = new StringBuilder();
                        Uri uri=Uri.parse(url2).buildUpon().appendPath(str).appendPath("reviews")
                                .appendQueryParameter("api_key",API_KEY).build();
                        Log.d("reviewURL",uri.toString());
                        try {
                            URL buildUrl = new URL(uri.toString());
                            HttpURLConnection connection = (HttpURLConnection)buildUrl.openConnection();
                            connection.setRequestMethod("GET");
                            InputStream in = connection.getInputStream();
                            BufferedReader br = new BufferedReader(new InputStreamReader(in));
                            String str = "";
                            while (str != null) {
                                str = br.readLine();
                                result.append(str).append("\n");
                                in.close();

                            }
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        if (result != null) {
                            try {
                                JSONObject jsonObject = new JSONObject(result.toString());
                                JSONArray reviewRes = jsonObject.getJSONArray("results");
                                for (int i = 0; i < reviewRes.length(); i++) {
                                    JSONObject revRes = reviewRes.getJSONObject(i);
                                    String Author = revRes.getString("author");
                                    String Content = revRes.getString("content");
                                    String Url = revRes.getString("url");
                                    ReviewPojo reviewPojo = new ReviewPojo(Author, Content, Url);
                                    reviewList.add(reviewPojo);
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        return null;
                    }

                    @Override
                    protected void onStartLoading() {
                        super.onStartLoading();
                        forceLoad();
                    }
                };
        }
        return null;
    }

    @Override
    public void onLoadFinished(Loader<ArrayList<TrailerVideoPojo>> loader, ArrayList<TrailerVideoPojo> data) {

        switch (loader.getId()){
            case loader_id:
                trailer_rv.setLayoutManager(new LinearLayoutManager(SecondActivity.this));
                trailer_rv.setAdapter(new TrailerVideoAdapter(SecondActivity.this,data));
                break;
            case review_id:
                review_rv.setLayoutManager(new LinearLayoutManager(SecondActivity.this));
                review_rv.setAdapter(new ReviewsAdapter(SecondActivity.this,reviewList));
        }

    }

    @Override
    public void onLoaderReset(Loader<ArrayList<TrailerVideoPojo>> loader) {

    }
}
