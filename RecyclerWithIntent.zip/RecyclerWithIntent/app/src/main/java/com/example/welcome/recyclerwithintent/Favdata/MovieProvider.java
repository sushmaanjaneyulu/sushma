package com.example.welcome.recyclerwithintent.Favdata;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

/**
 * Created by welcome on 5/24/2018.
 */

public class MovieProvider extends ContentProvider {
    private static final UriMatcher urimatcher = buildUrimatcher();
    private FavouriteDbHelper favouriteDbHelper;

    private static final int MOVIES = 100;
    private static final int MOVIES_ITEM = 101;

    private static SQLiteQueryBuilder oFavBuilder;

    static {
        oFavBuilder = new SQLiteQueryBuilder();
    }

    private static UriMatcher buildUrimatcher() {
        final UriMatcher uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        final String authority = FavContract.CONTENT_AUTHORITY;
        uriMatcher.addURI(authority, FavContract.PATH_MOVIES, MOVIES);
        uriMatcher.addURI(authority, FavContract.PATH_MOVIES + "/*", MOVIES_ITEM);
        return uriMatcher;
    }

    @Override
    public boolean onCreate() {
        Context context = getContext();
        favouriteDbHelper = new FavouriteDbHelper(getContext());
        return true;
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection, @Nullable String[] selectionArgs, @Nullable String sortOrder) {
        Cursor cursor;
        switch (urimatcher.match(uri)) {
            case MOVIES: {
                cursor = favouriteDbHelper.getReadableDatabase()
                        .query(FavContract.FavEntryMovies.TABLE_NAME,
                                projection,
                                selection,
                                selectionArgs,
                                null,
                                null,
                                sortOrder);
                break;
            }

            case MOVIES_ITEM: {
                cursor = favouriteDbHelper.getReadableDatabase()
                        .query(FavContract.FavEntryMovies.TABLE_NAME,
                                projection,
                                selection,
                                selectionArgs,
                                null,
                                null,
                                sortOrder);
                break;
            }
            default:
              throw new UnsupportedOperationException("Unknown Uri:" + uri);
        }
        if (getContext() != null) {
            cursor.setNotificationUri(getContext().getContentResolver(), uri);
        }
        return cursor;
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {

        return null;
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues contentValues) {

        long id=0;
        final SQLiteDatabase db= favouriteDbHelper.getWritableDatabase();
        final int matcher = urimatcher.match(uri);
        switch (matcher) {
            case MOVIES: {

                id = db.insert(FavContract.FavEntryMovies.TABLE_NAME, null, contentValues);

                break;
            }
            default:
                throw new UnsupportedOperationException("Unknown uri:" + uri);
        }
        Uri uri1=Uri.parse("" + id);
        return uri1;
    }

    @Override
    public int delete(@NonNull Uri uri, @Nullable String selection, @Nullable String[] selectionArgs) {
        final int matcher = urimatcher.match(uri);
        int deleteRows = 0;
        switch (matcher) {
            case MOVIES_ITEM: {

                deleteRows=favouriteDbHelper.getWritableDatabase().delete(FavContract.FavEntryMovies.TABLE_NAME,selection,selectionArgs);
                break;
            }
            default:
                throw new UnsupportedOperationException("Unknown uri:" + uri);
        }

        if (deleteRows != 0 ) {
            getContext().getContentResolver().notifyChange(uri, null);

        }
        Log.i("deleted","rows deleted");
        return deleteRows;
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues values, @Nullable String selection, @Nullable String[] selectionArgs) {

        return 0;
    }
}
